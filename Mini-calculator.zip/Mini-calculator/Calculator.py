import tkinter as tk

class Calculator:
    def __init__(self):
        # Create the main window
        self.window = tk.Tk()
        self.window.title("Calculator")

        # Create the input field
        self.entry = tk.Entry(self.window, width=30)
        self.entry.pack()

        # Create the number buttons
        self.buttons = []
        for i in range(0, 10):
            button = tk.Button(self.window, text=str(i), command=lambda i=i: self.add_number(i))
            self.buttons.append(button)

        self.buttons[0].grid(row=3, column=0)  # 0
        self.buttons[1].grid(row=3, column=1)  # 1
        self.buttons[2].grid(row=3, column=2)  # 2

        self.buttons[3].grid(row=2, column=0)  # 3
        self.buttons[4].grid(row=2, column=1)  # 4
        self.buttons[5].grid(row=2, column=2)  # 5

        self.buttons[6].grid(row=1, column=0)  # 6
        self.buttons[7].grid(row=1, column=1)  # 7
        self.buttons[8].grid(row=1, column=2)  # 8

        self.buttons[9].grid(row=0, column=0)  # 9

        # Create the operation buttons
        self.operation_buttons = []
        for operation in ['+', '-', '*', '/', '%', '**', 'sqrt', '!']:
            button = tk.Button(self.window, text=operation, command=lambda operation=operation: self.add_operation(operation))
            self.operation_buttons.append(button)

        self.operation_buttons[0].grid(row=0, column=3)  # +
        self.operation_buttons[1].grid(row=0, column=4)  # -
        self.operation_buttons[2].grid(row=0, column=5)  # *
        self.operation_buttons[3].grid(row=1, column=3)  # /
        self.operation_buttons[4].grid(row=1, column=4)  # %
        self.operation_buttons[5].grid(row=1, column=5)  # **
        self.operation_buttons[6].grid(row=2, column=3)  # sqrt
        self.operation_buttons[7].grid(row=2, column=4)  # !

        # Create the equals button
        self.equal_button = tk.Button(self.window, text="=", command=self.calculate)
        self.equal_button.grid(row=3, column=3)

        # Create the clear button
        self.clear_button = tk.Button(self.window, text="C", command=self.clear)
        self.clear_button.grid(row=3, column=4)

        # Initialize the current operation and operands
        self.current_operation = None
        self.operand1 = None
        self.operand2 = None

    def add_number(self, number):
        # Add the number to the input field
        self.entry.insert(tk.END, str(number))

    def add_operation(self, operation):
        # Store the current operation and operands
        self.operand1 = float(self.entry.get())
        self.current_operation = operation
        self.entry.delete(0, tk.END)

    def calculate(self):
        # Calculate the result
        self.operand2 = float(self.entry.get())
        result = self.calculate_result(self.operand1, self.operand2, self.current_operation)

        # Display the result
        self.entry.delete(0, tk.END)
        self.entry.insert(tk.END, str(result))

    def clear(self):
        # Clear the input field and reset variables
        self.entry.delete(0, tk.END)
        self.current_operation = None
        self.operand1 = None
        self.operand2 = None

    def calculate_result(self, operand1, operand2, operation):
        if operation == '+':
            return operand1 + operand2
        elif operation == '-':
            return operand1 - operand2
        elif operation == '*':
            return operand1 * operand2
        elif operation == '/':
            return operand1 / operand2
        elif operation == '%':
            return operand1 % operand2
        elif operation == '**':
            return operand1 ** operand2
        elif operation == 'sqrt':
            return operand1 ** 0.5
        elif operation == '!':
            return factorial(operand1)

# Run the calculator
calculator = Calculator()
calculator.window.mainloop()