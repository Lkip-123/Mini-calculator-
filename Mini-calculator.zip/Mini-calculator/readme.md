This script is a simple calculator with basic operations. Easy to use and has a graphical interface (GUI)

Requirements
Python version 3.6 and higher
tkinter library 
Usage
Go to the directory with the calculator.py script
use python calculator.py command

Contact:
Username telegram: @LKIP_OFFICAL
Telegram channel: https://t.me/LKIP_projects